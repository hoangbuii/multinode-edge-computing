@echo off

mkdir C:\ecwcli 2>nul

mkdir C:\ecwcli\bin 2>nul

mkdir C:\ecwcli\tmp 2>nul

copy /Y "%~dp0ecwcli.exe" C:\ecwcli\bin

setx PATH "%PATH%;C:\ecwcli\bin" /M

echo Install Successfully

pause
